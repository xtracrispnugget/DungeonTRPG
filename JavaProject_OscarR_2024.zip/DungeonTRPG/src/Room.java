import java.util.ArrayList;
import java.util.List;

public class Room {
    public final String description;
    private Monster monster;
    private Weapon weapon;

    private Room north;
    private Room south;
    private Room east;
    private Room west;

    public Room(String description, Monster monster, Weapon weapon) {
        this.description = description;
        this.monster = monster;
        this.weapon = weapon;
    }

    public boolean hasWeapon() {
        return weapon != null;
    }

    public Weapon getWeapon() {
        return weapon;
    }

    public Monster getMonster(){
        return monster;
    }

    public boolean hasMonster(){
        return monster != null;
    }

    public boolean hasExit(Direction d){
        if(d == Direction.NORTH) {
            return north != null;
        } else if (d == Direction.EAST){
            return east != null;
        } else if (d == Direction.SOUTH){
            return south != null;
        } else { //d == Direction.WEST)
            return west != null;
        }

    }

    public void setWeapon(Weapon weapon){
        this.weapon = weapon;
    }

    public void setMonster(Monster monster){
        this.monster = monster;
    }

    public void setEast(Room east) {
        this.east = east;
    }

    public void setSouth(Room south) {
        this.south = south;
    }

    public void setWest(Room west){
        this.west = west;
    }

    public void setNorth(Room north){
        this.north = north;
    }

    public Room getNeighbour(Direction d){
        if(d == Direction.NORTH) {
            return north;
        }else if (d == Direction.EAST){
            return east;
        }else if (d == Direction.SOUTH){
            return south;
        }else{
            return west;
        }
    }
}
