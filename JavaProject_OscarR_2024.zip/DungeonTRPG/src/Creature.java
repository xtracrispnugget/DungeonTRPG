import java.util.Random;

public abstract class Creature {
    private int hp_current;
    public final int hp_max;
    private int ac;

    public Creature(int maxhp, int ac) {
        this.hp_max = maxhp;
        this.hp_current = maxhp;
        this.ac = ac;
    }

    public int getHp_current() {
        return hp_current;
    }

    public int getAc() {
        return ac;
    }


    public void takeDamage(int dmg){
        this.hp_current = hp_current - dmg;
    }

    public boolean isAlive(){
        return hp_current > 0;
    }

}
