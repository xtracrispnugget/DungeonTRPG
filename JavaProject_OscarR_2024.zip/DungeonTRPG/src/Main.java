import java.util.Random;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in); // to prompt user for inputs in the console
        Random rand = new Random(); //used to simulate dice rolls
        Weapon startingWeapon = new Weapon("Rusty Dagger", 3, DamageType.PIERCE);
        Warrior protagonist = new Warrior(15, 4, startingWeapon); // the main character
        Room currentRoom = initRooms();

        System.out.println("You find yourself in " + currentRoom.description);
        // main game loop
        while(true){
            if(currentRoom.hasMonster()){
                boolean battleWon = runBattle(rand, sc, protagonist, currentRoom.getMonster());
                if(battleWon){
                    currentRoom.setMonster(null);
                    continue;
                }else{
                    break;
                }
            }
            int action = promptUserForInput(sc);

            // running conditionals for Weapon finding / switching
            if (action == 1){
                searchRoom(sc, currentRoom, protagonist);
            }
            // Attempting to go North
            if(action == 2){
                currentRoom = attemptToExit(currentRoom, Direction.NORTH);
            }
            // Attempting to go East
            if(action == 3){
                currentRoom = attemptToExit(currentRoom, Direction.EAST);
            }
            // Attempting to go South
            if(action == 4){
                currentRoom = attemptToExit(currentRoom, Direction.SOUTH);
            }
            // Attempting to go East
            if(action == 5){
                currentRoom = attemptToExit(currentRoom, Direction.WEST);
            }
        }
    }

    // initialises room matrix with content in each room and returns the starting room
    public static Room initRooms(){
        // init monsters
        Monster skeleton = new Monster("skeleton", "bony fists", 10, 5, 12, DamageType.PIERCE, DamageType.CRUSH);

        //init weapons
        Weapon twoHandedSword = new Weapon("Two-handed Sword of Death Power Destruction", 12, DamageType.PIERCE);

        //init rooms
        Room southwest = new Room("Empty room (SOUTH WEST)", null, null);
        Room south = new Room("Dark room (SOUTH)", skeleton, null);
        Room west = new Room("Room with hidden treasure (WEST)", null, twoHandedSword);

        //link rooms
        southwest.setEast(south);
        south.setWest(southwest);
        southwest.setNorth(west);
        west.setSouth(southwest);


        return southwest;
    }

    // this function handles user input. if invalid input is entered the user is prompted to try again
    public static int inputInt(Scanner sc, int min, int max){
        while(true) {
            try {
                int i = sc.nextInt();
                if (i<min || i>max) {
                    System.err.println("Must be a number between " + min + " and " + max);
                    continue;
                }
                return i;
            } catch (Exception e) {
                System.err.println("Invalid input baby, try again!");
                sc.nextLine();
            }
        }
    }

    // running a battle until either you or the monster is dead
    // true is returned if battle is won, false if battle is lost.
    public static boolean runBattle(Random rand, Scanner sc, Warrior protagonist, Monster monster){
        System.out.println("a " + monster.name + " jumps out of the shadow and attacks you");
        System.out.println("Starting battle");
        int round = 1;
        while(true){
            System.out.println("\n---- Round " + round + " -----");
            sc.next();
            protagonist.attack(rand, monster);
            if(!monster.isAlive()){
                System.out.println("You defeated the " + monster.name + "!");
                return true;
            }
            System.out.println("The skeleton seems to be " + monster.getHpStatus());
            sc.next();
            monster.attack(rand, protagonist);
            if(!protagonist.isAlive()) {
                System.out.println("You fought valiantly but died in battle");
                System.out.println(" -- GAME OVER --");
                return false;
            }
            round++;
        }
    }

    public static int promptUserForInput(Scanner sc) {
        System.out.println("-------------");
        System.out.println("Choose your action");
        System.out.println("1: Examine room, 2: Exit north, 3: Exit east, 4: exit south, 5: exit west");
        System.out.println("--------------");
        return inputInt(sc, 1, 5);
    }

    public static void searchRoom(Scanner sc, Room currentRoom, Warrior protagonist){
        if(currentRoom.hasWeapon()){
            System.out.println("You search the room and find a " + currentRoom.getWeapon().name + " hidden in the corner");
            System.out.println("Choose your action");
            System.out.println("1: Replace " + currentRoom.getWeapon().name + " with you current weapon, 2: Keep your " + protagonist.getWeapon().name);
            int action = inputInt(sc, 1,2);
            if(action == 1){
                System.out.println("You switch weapons");
                protagonist.setWeapon(currentRoom.getWeapon());
                currentRoom.setWeapon(null);
            }else{
                System.out.println("You stick to your " + protagonist.getWeapon().name);
            }
        }else{
            System.out.println("You find nothing of interest.");
        }
    }

    // this function returns the Room that the protagonist now is in, i.e. if the exit
    // was successful then the new room will be returned otherwise the current one will be returned
    public static Room attemptToExit(Room currentRoom, Direction direction){
        if(currentRoom.hasExit(direction)){
            Room nextRoom = currentRoom.getNeighbour(direction);
            System.out.print("You leave the " + currentRoom.description);
            System.out.println(" and enter " + nextRoom.description);
            currentRoom = nextRoom;
        } else{
            System.err.println("The path north is blocked, you will have to find another way to proceed.");
        }
        return currentRoom;
    }
}