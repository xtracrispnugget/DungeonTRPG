public enum DamageType {
    CRUSH,
    PIERCE
}
