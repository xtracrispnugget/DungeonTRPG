public class Weapon {
    public final String name;
    public final int dmg;
    public final DamageType damageType;

    public Weapon(String name, int dmg, DamageType damageType) {
        this.name = name;
        this.dmg = dmg;
        this.damageType = damageType;
    }
}
