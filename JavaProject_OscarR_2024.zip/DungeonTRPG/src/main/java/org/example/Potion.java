package org.example;

public class Potion {

    public final String name;

    public final int healing;

    public Potion (String name, int heal)
    {
        this.name = name;
        this.healing = heal;
    }
}
