package org.example;

import java.util.Random;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in); // to prompt user for inputs in the console
        Random rand = new Random(); //used to simulate dice rolls
        Weapon startingWeapon = new Weapon("Rusty Dagger", 3, DamageType.PIERCE);
        Warrior protagonist = new Warrior(15, 6, startingWeapon); // the main character
        Potion healing = new Potion("Lesser Healing Potion", 5);
        Room currentRoom = initRooms();

        System.out.println("You find yourself in " + currentRoom.description);
        // main game loop
        while(true){
            if(currentRoom.hasMonster()){
                boolean battleWon = runBattle(rand, sc, protagonist, currentRoom.getMonster());
                if(battleWon){
                    currentRoom.setMonster(null);
                    continue;
                }else{
                    break;
                }
            }
            int action = promptUserForInput(sc);

            // running conditionals for Weapon finding / switching
            if (action == 1){
                searchRoom(sc, currentRoom, protagonist, healing);
            }
            // Attempting to go North
            if(action == 2){
                currentRoom = attemptToExit(currentRoom, Direction.NORTH);
            }
            // Attempting to go East
            if(action == 3){
                currentRoom = attemptToExit(currentRoom, Direction.EAST);
            }
            // Attempting to go South
            if(action == 4){
                currentRoom = attemptToExit(currentRoom, Direction.SOUTH);
            }
            // Attempting to go East
            if(action == 5){
                currentRoom = attemptToExit(currentRoom, Direction.WEST);
            }
        }
    }

    // initialises room matrix with content in each room and returns the starting room
    public static Room initRooms(){
        // init monsters
        Monster skeleton = new Monster("skeleton", "bony fists", 12, 5, 10, DamageType.PIERCE, DamageType.CRUSH);
        Monster zombie = new Monster("zombie","rotting fists" ,15, 3,8,DamageType.CRUSH, DamageType.PIERCE);
        Monster flameElemental = new Monster("Flame Elemental of fire and heat and hot stuff", "flaming arms", 30, 8,10,DamageType.FIRE, DamageType.COLD);

        //init weapons
        Weapon twoHandedSword = new Weapon("Two-handed Sword of Death Power Destruction", 6, DamageType.PIERCE);
        Weapon oneHandedMace = new Weapon("Dwarven Mace of A lot of dwarves", 6,DamageType.CRUSH);
        Potion healingPotion = new Potion("Healing Potion", 5);
        Weapon goldenSpear = new Weapon("Golden Spear of Icy Cold Spears and stuff", 12, DamageType.COLD);


        //init rooms
        Room start = new Room("Empty room (START)", null, null, null);
        Room east = new Room("a Dark room (EAST)", skeleton, null, null);
        Room north = new Room("a Room with hidden treasure (NORTH)", null, twoHandedSword, null);
        Room west = new Room("Ruined Dwarven Catacombs (WEST)", null, oneHandedMace, null);
        Room south = new Room("a Smelly Dark room. You hear a noise, and the door locks behind you.", zombie, null, null);
        Room east2 = new Room("the Potion Room (EAST EAST)", null,null, healingPotion );
        Room eastsouth = new Room("a Dark Potion room (EAST SOUTH)", skeleton, null, null);
        Room eastWing = new Room("a Golden room with gold and stuff(EAST WING)", null, goldenSpear, null);
        Room south2 = new Room("an empty room", null, null,healingPotion);
        Room bossRoom = new Room("an Ominous Room, lid up by a single light source, in the middle of the room.", flameElemental, null, null);



        //link rooms
        start.setEast(east); //connect start -> east
        start.setWest(west); //connect start -> west
        start.setSouth(south); //connect start -> south
        start.setNorth(north); //connect start -> north

        north.setSouth(start);  //connect north -> start

        west.setEast(start); //connect west -> start

        east.setWest(start); //connect east -> start
        east.setEast(east2); //connect east -> east2

        south.setSouth(south2);//connect south -> south2

        eastsouth.setEast(eastWing);
        eastsouth.setNorth(east2);

        east2.setSouth(eastsouth); //connect east2 -> eastSouth
        east2.setWest(east); //connect east2 -> east
        eastWing.setWest(eastsouth); //connect eastWing -> east2


        south2.setNorth(south); //connect south2 -> south
        south2.setSouth(bossRoom); //connect south2 -> bossRoom
        bossRoom.setNorth(south2); //connect bossRoom -> south2


        return start;
    }

    // this function handles user input. if invalid input is entered the user is prompted to try again
    public static int inputInt(Scanner sc, int min, int max){
        while(true) {
            try {
                int i = sc.nextInt();
                if (i<min || i>max) {
                    System.err.println("Must be a number between " + min + " and " + max);
                    continue;
                }
                return i;
            } catch (Exception e) {
                System.err.println("Invalid input baby, try again!");
                sc.nextLine();
            }
        }
    }

    // running a battle until either you or the monster is dead
    // true is returned if battle is won, false if battle is lost.
    public static boolean runBattle(Random rand, Scanner sc, Warrior protagonist, Monster monster){
        System.out.println("a " + monster.name + " jumps out of the shadow and attacks you!");
        System.out.println("Starting battle");
        int round = 1;
        while(true){
            System.out.println("\n---- Round " + round + " -----");
            sc.next();
            protagonist.attack(rand, monster);
            if(!monster.isAlive()){
                System.out.println("You defeated the " + monster.name + "!");
                System.out.println("You currently have " + protagonist.getHp_current() + " hp.");
                return true;
            }
            System.out.println("The " + monster.name + " seems to be " + monster.getHpStatus());
            sc.next();
            monster.attack(rand, protagonist);
            if(!protagonist.isAlive()) {
                System.out.println("You fought valiantly but died in battle.");
                System.out.println(" -- GAME OVER --");
                return false;
            }
            round++;
        }
    }

    public static int promptUserForInput(Scanner sc) {
        System.out.println("-------------");
        System.out.println("Choose your action");
        System.out.println("1: Examine room, 2: Exit north, 3: Exit east, 4: exit south, 5: exit west.");
        System.out.println("--------------");
        return inputInt(sc, 1, 5);
    }

    public static void searchRoom(Scanner sc, Room currentRoom, Warrior protagonist, Potion potion){
        if(currentRoom.hasWeapon()){
            System.out.println("You search the room and find a " + currentRoom.getWeapon().name + " hidden in the corner");
            System.out.println("Choose your action.");
            System.out.println("1: Replace " + currentRoom.getWeapon().name + " with you current weapon, 2: Keep your " + protagonist.getWeapon().name + ".");
            int action = inputInt(sc, 1,2);
            if(action == 1){
                System.out.println("You switch weapons.");
                Weapon temp = protagonist.getWeapon();
                protagonist.setWeapon(currentRoom.getWeapon());
                currentRoom.setWeapon(temp);
            }else{
                System.out.println("You stick to your " + protagonist.getWeapon().name +".");
            }
        }
        else if(currentRoom.hasPotion()){
            System.out.println("You search the room and find a " + currentRoom.getPotion().name + " on a shelf.");
            if(protagonist.getHp_current() == protagonist.getHp_max())
            {
                System.out.println("You currently have no injuries to heal.");
                System.out.println("Do you want to drink the " + currentRoom.getPotion().name + "?" );
            } else {
                System.out.println("You currently have " + protagonist.getHp_current() + " hp left.");
                System.out.println("Do you want to drink the " + currentRoom.getPotion().name + "?" );
            }
            System.out.println("--------------");
            System.out.println("1: Drink the " + currentRoom.getPotion().name + "." + " 2: Let the " + currentRoom.getPotion().name + " be.");
            System.out.println("--------------");
            int action = inputInt(sc, 1,2);
            if(action == 1) {
                //protagonist.heal(currentRoom.getPotion().healing);
                if (protagonist.getHp_current() == protagonist.hp_max)
                {
                    System.out.println("You drink the potion, but theres no injuries to heal.");
                    currentRoom.setPotion(null);
                }
                else if (currentRoom.getPotion().healing > (protagonist.getHp_current() - protagonist.hp_max)) {
                    protagonist.heal(currentRoom.getPotion().healing);
                    System.out.println("You drink the potion and get healed fully up to " + protagonist.getHp_max() + " hp.");
                    System.out.println("You still have " + protagonist.getHp_current() + " hp.");
                    currentRoom.setPotion(null);
                } else {
                    protagonist.heal(currentRoom.getPotion().healing);
                    System.out.println("You drink the potion and get healed for " + currentRoom.getPotion().healing + " hp.");
                    System.out.println("You now have " + protagonist.getHp_current() + " hp.");
                    currentRoom.setPotion(null);
                }
            }else{
                System.out.println("You let the " + currentRoom.getPotion().name + " be.");
            }
        }
        else{
            System.out.println("You find nothing of interest.");
        }
    }

    // this function returns the Room that the protagonist now is in, i.e. if the exit
    // was successful then the new room will be returned otherwise the current one will be returned
    public static Room attemptToExit(Room currentRoom, Direction direction){
        if(currentRoom.hasExit(direction)){
            Room nextRoom = currentRoom.getNeighbour(direction);
            System.out.print("You leave the " + currentRoom.description);
            System.out.println(" and enter " + nextRoom.description);
            currentRoom = nextRoom;
        } else{
            System.err.println("The path north is blocked, you will have to find another way to proceed.");
        }
        return currentRoom;
    }
}