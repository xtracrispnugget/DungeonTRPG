package org.example;
public enum HpStatus {
    UNINJURED, BARELY_INJURED, INJURED, BADLY_WOUNDED, NEAR_DEATH
}
