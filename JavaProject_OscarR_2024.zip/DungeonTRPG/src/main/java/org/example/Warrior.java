package org.example;
import java.util.Random;

public class Warrior extends Creature {
    private Weapon weapon;
    private int health;


    public Warrior(int maxhp, int ac, Weapon weapon) {
        super(maxhp, ac);
        this.weapon = weapon;
        this.health = maxhp;
    }

    public Weapon getWeapon(){
        return this.weapon;
    }

    public void setWeapon(Weapon weapon) {
        this.weapon = weapon;
    }


    // simulates both the hit dice roll and the damage dice roll in monster is hit
    // damage modifiers are also calculated
    public void attack(Random rand, Monster monster){
        System.out.println("You swing your " + weapon.name);
        int hitRoll = rand.nextInt(20) + 1;
        if (hitRoll >= monster.getAc()){
            int dmg = rand.nextInt(weapon.dmg) + 1;
            // adding damage modifiers
            if(monster.weakness == weapon.damageType){
                dmg *= 2;
            } else if(monster.resistant == weapon.damageType){
                dmg /= 2;
            }
            if(hitRoll == 20){
                dmg *=2;
                System.out.println("and crit the " + monster.name + " for " + dmg + " damage!!");
            }else{
                System.out.println("and hit the " + monster.name + " for " + dmg + " damage");
            }
            if(monster.weakness == weapon.damageType){
                System.out.println("The " + monster.name + " seems to be especially vulnerable to your weapon");
            }else if(monster.resistant == weapon.damageType){
                System.out.println("Your " + weapon.name + " seems weak against the " + monster.name);
            }
            monster.takeDamage(dmg);
        }else{
            System.out.println("and miss");
        }

    }


}
