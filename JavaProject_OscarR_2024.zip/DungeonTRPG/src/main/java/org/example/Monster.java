package org.example;

import java.util.Random;

public class Monster extends Creature{
    public final String name;
    public final String weaponName;
    public final int maxDmg;
    public final DamageType resistant;
    public final DamageType weakness;

    public Monster(String name, String weaponName, int hp, int ac, int maxDmg, DamageType resistant, DamageType weakness) {
        super(hp, ac);
        this.name = name;
        this.weaponName = weaponName;
        this.maxDmg = maxDmg;
        this.resistant = resistant;
        this.weakness = weakness;
    }

    public void attack(Random rand, Warrior protagonist) {
        System.out.println("The " + getMonsterName() + " swings its " + weaponName + "...");
        int hitRoll = rand.nextInt(20) + 1;
        if (hitRoll >= protagonist.getAc()){
            int dmg = rand.nextInt(maxDmg) + 1;
            if (hitRoll == 20){
                dmg *= 2;
                System.out.println("and hit you for " + dmg + " damage");
            }else {
                System.out.println("and hit you for " + dmg + " damage");
            }
            protagonist.takeDamage(dmg);
        }else{
            System.out.println("and miss");
        }
    }

    public String getMonsterName() {
        return name;
    }

    public HpStatus getHpStatus(){
        double hpProcentage = (double) getHp_current() / (double) hp_max;
        if (hpProcentage > 0.99){
            return HpStatus.UNINJURED;
        }
        if (hpProcentage > 0.75){
            return HpStatus.BARELY_INJURED;
        }
        if (hpProcentage > 0.5){
            return HpStatus.INJURED;
        }
        if (hpProcentage > 0.25){
            return HpStatus.BADLY_WOUNDED;
        }
        return HpStatus.NEAR_DEATH;
    }


}
