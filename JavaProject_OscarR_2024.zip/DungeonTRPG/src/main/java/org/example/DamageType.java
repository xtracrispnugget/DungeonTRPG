package org.example;

public enum DamageType {
    CRUSH,
    PIERCE,
    FIRE,
    COLD,
}
